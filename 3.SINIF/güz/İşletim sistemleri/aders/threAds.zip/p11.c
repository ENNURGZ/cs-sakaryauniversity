#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>

int main() {
    pid_t pid = fork();
    if (pid == 0) {
        printf("Child: doing some work...\n");
        sleep(1);

        printf("Child: About to self-halt...\n");
        raise(SIGSTOP);

        printf("Child: I'm awake again! Doing some more work...\n");
        sleep(2);

        printf("Child: goodbye!\n");
        //exit(0); :)
    }
    
    printf("Parent: doing some work...\n");
    sleep(2);

    printf("Parent: Waiting for child to self-halt...\n");
    waitpid(pid, NULL, WUNTRACED);
    printf("Parent: child has paused! We've reached the sync point. About to continue\n\n");
    kill(pid, SIGCONT);
    
    
    printf("Parent: sent SIGCONT, doing some more work in the parent...\n");
    sleep(1);
    
    printf("Parent: waiting for child to exit...");
    waitpid(pid, NULL, 0);
    printf("Parent: Child has exited\n");
    return 0;
}
